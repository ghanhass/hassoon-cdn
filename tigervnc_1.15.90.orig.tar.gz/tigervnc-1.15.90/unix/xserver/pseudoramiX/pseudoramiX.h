/*
 * Minimal implementation of PanoramiX/Xinerama
 */

void
PseudoramiXAddScreen(int x, int y, int w, int h);
void
PseudoramiXResetScreens(void);
